-- Kazrogal
UPDATE `creature_template` SET `mechanic_immune_mask` = '1073463287', `AIName` = '', `Scriptname` ='boss_kazrogal' WHERE `entry` = '17888';
