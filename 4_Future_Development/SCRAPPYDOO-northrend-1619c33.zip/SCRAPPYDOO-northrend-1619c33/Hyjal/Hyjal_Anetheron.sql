-- Anetheron
UPDATE `creature_template` SET `mechanic_immune_mask` = '1073463287', `AIName` = '', `Scriptname` ='boss_anetheron' WHERE `entry` = '17808';
UPDATE `creature_template` SET `mechanic_immune_mask` = '1073741823', `flags_extra` = '256', `AIName` = '', `Scriptname` ='mob_towering_infernal' WHERE `entry` = '17818';



