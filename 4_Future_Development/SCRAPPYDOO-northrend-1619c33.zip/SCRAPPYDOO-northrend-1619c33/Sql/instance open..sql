-- Azjol Nerub area trigger update OPEN
UPDATE `areatrigger_teleport` SET `required_quest_done` = '0', `required_quest_done_heroic` = '0', `required_failed_text` = 'NULL' WHERE `id` IN (5115,5113,5117);
-- Halls Of ligting area triger update OPEN
UPDATE `areatrigger_teleport` SET `required_quest_done` = '0', `required_quest_done_heroic` = '0', `required_failed_text` = 'NULL' WHERE `id` IN (5093,5091);
-- Ahnkahet area triger update OPEN
UPDATE `areatrigger_teleport` SET `required_quest_done` = '0', `required_quest_done_heroic` = '0', `required_failed_text` = 'NULL' WHERE `id` IN (5215,5213);
-- Nexus area triger update OPEN
UPDATE `areatrigger_teleport` SET `required_quest_done` = '0', `required_quest_done_heroic` = '0', `required_failed_text` = 'NULL' WHERE `id` IN (4983,4981);
-- Naxxramas 
UPDATE `areatrigger_teleport` SET `required_quest_done` = '0', `required_quest_done_heroic` = '0', `required_failed_text` = 'NULL' WHERE `id` IN (5191,5192,5193,5194,5196,5197,5198,5199);
-- Nexus
UPDATE `areatrigger_teleport` SET `required_quest_done` = '0', `required_quest_done_heroic` = '0', `required_failed_text` = 'NULL' WHERE `id` IN (4983,4981);
