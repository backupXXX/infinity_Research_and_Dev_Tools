DELETE FROM `reputation_reward_rate` WHERE `faction` IN (1090,1091,1098,1106,1119);
