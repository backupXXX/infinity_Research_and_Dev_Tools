UPDATE creature_template SET unit_flags=64 WHERE entry=17307;
