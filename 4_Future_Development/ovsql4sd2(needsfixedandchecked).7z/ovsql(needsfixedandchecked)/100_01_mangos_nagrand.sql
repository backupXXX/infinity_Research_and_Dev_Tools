UPDATE creature_template SET unit_flags=0 WHERE entry=19055;

UPDATE `creature_template` SET `ScriptName` = 'npc_Kurenai_Captive' WHERE `entry` =18209;