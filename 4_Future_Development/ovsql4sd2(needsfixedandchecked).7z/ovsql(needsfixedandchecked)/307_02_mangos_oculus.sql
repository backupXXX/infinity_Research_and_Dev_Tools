-- oculus

-- mechanic immune masks
UPDATE creature_template SET mechanic_immune_mask = '617299803' WHERE entry IN(27654,27447,27655,27656,31558,31559,31560,31561);
