# Entfernen von Auto close bei der Tür nach Maulgar
UPDATE gameobject_template SET data2=0 WHERE entry=184468;
