-- pit of saron

-- mechanic immune masks
UPDATE creature_template SET mechanic_immune_mask = '617299803' WHERE entry IN(36494,36476,36477,36658,36498,36938,37613,37627);
