UPDATE creature_template SET maxhealth=4954780, minhealth=4954780, dmg_multiplier=45 WHERE entry=19622; -- Kael'thas
UPDATE creature_template SET maxhealth=301349, minhealth=301349, dmg_multiplier=12 WHERE entry=20064; -- Thaladred
UPDATE creature_template SET maxhealth=301349, minhealth=301349, dmg_multiplier=12 WHERE entry=20063; -- Telonicus
UPDATE creature_template SET maxhealth=301349, minhealth=301349, dmg_multiplier=12 WHERE entry=20060; -- Lord Sangulnar
UPDATE creature_template SET maxhealth=276340, minhealth=276340, dmg_multiplier=1.4 WHERE entry=20062; -- Capernian
UPDATE creature_template SET maxhealth=6748930, minhealth=6748930, dmg_multiplier=45 WHERE entry=19516; -- Void Reaver
UPDATE creature_template SET maxhealth=4923880, minhealth=4923880 WHERE entry=19514; -- Al'ar
UPDATE creature_template SET maxhealth=4359000, minhealth=4359000, dmg_multiplier=45 WHERE entry=18805; --  Solarian
