-- close ruby sanctum
UPDATE `areatrigger_teleport` SET `required_level` = 90 WHERE `id` = 5869;
