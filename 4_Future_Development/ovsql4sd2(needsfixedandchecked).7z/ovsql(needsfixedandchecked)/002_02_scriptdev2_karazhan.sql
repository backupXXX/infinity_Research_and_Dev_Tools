-- ScriptDev2 karazhan netherspite fixes

UPDATE `script_texts` SET `type` =  '3' WHERE `entry` IN (-1532090,-1532089);
