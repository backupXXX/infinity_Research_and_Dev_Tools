# zangarmarsh fixes

#fix creature 17901
UPDATE `creature` SET `position_x` = -322.21, `position_y` = 5508.77, `position_z` = 23.91, `orientation` = 0.202367 WHERE `id` = 17901;
