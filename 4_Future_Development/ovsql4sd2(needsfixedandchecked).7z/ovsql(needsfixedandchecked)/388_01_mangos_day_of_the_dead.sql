-- fixes for day of the dead 

-- fix achievement 3456
UPDATE `creature_template` SET `ScriptName` = 'npc_catrina' WHERE `entry` =34383;