UPDATE battleground_template SET MinPlayersPerTeam=12 WHERE id=1;
UPDATE battleground_template SET MinPlayersPerTeam=5 WHERE id=2;
UPDATE battleground_template SET MinPlayersPerTeam=7 WHERE id=3;
UPDATE battleground_template SET MinPlayersPerTeam=7 WHERE id=7;