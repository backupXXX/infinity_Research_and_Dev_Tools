-- feralas fixes

-- fix quest 2987
UPDATE `gameobject` SET `id` = '144064' WHERE `id` = 144050;