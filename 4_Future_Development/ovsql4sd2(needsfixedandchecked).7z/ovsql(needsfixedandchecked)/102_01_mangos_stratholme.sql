-- Stratholme Tür
UPDATE `gameobject_template` SET `data1` = '299', `data2` = '3000' WHERE `entry` =175967;
