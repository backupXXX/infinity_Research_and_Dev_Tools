/* BLACK TEMPLE */
update `creature_onkill_reputation` set `RewOnKillRepValue1` = 250 where `creature_id` = 22948;
UPDATE `gameobject_template` SET `data0` = '0' where `entry` = 185480;
