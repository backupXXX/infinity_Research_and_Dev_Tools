/* AZJOL-NERUB */
UPDATE `gameobject_template` SET `faction` = 114 where `entry` in (192395);
update creature_template set AIName = '', scriptName = 'npc_watcher_gashra' where entry = 28730;
update creature_template set AIName = '', scriptName = 'npc_watcher_silthik' where entry = 28731;
update creature_template set AIName = '', scriptName = 'npc_watcher_narjil' where entry = 28729;
