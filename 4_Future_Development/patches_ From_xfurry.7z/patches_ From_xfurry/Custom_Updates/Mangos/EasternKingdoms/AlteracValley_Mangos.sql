/* ALTERAC VALLEY */
-- Scriptnames
update `creature_template` set ScriptName = "boss_galvangar" where entry = 11947;
update `creature_template` set ScriptName = "boss_balinda" where entry = 11949;
update `creature_template` set ScriptName = "boss_vanndar" where entry = 11948;
update `creature_template` set ScriptName = "boss_drekthar" where entry = 11946;
update `creature_template` set ScriptName = "boss_drakan" where entry = 12121;
update `creature_template` set ScriptName = "boss_duros" where entry = 12122;
update `creature_template` set ScriptName = "mob_water_elemental" where entry = 25040;
update `creature_template` set ScriptName = "mob_av_marshal_or_warmaster" where entry in (14762, 14763, 14764, 14765, 14772, 14773, 14776, 14777);
