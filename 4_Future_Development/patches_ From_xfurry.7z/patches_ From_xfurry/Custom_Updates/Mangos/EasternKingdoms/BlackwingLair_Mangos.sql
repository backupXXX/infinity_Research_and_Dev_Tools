/* BLACKWING LAIR */
UPDATE `gameobject_template` SET `faction` = 114 WHERE `entry` in (176964, 176965, 176966, 179115, 179116, 179117, 179364, 179365);
update `instance_template` set `scriptName` = 'instance_blackwing_lair' where `map` = 469;
