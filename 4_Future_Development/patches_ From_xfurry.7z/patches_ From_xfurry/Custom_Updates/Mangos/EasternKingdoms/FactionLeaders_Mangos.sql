/* FACTION LEADERS */
UPDATE `creature_template` SET `ScriptName`='boss_king_varian_wrynn' WHERE `entry`=29611;
UPDATE `creature_template` SET `ScriptName`='boss_king_magni_bronzebreard' WHERE `entry`=2784;
UPDATE `creature_template` SET `ScriptName`='boss_high_tinker_mekkatorque' WHERE `entry`=7937;
UPDATE `creature_template` SET `ScriptName`='boss_prophet_velen' WHERE `entry`=17468;
UPDATE `creature_template` SET `ScriptName`='boss_tyrande_whisperwind' WHERE `entry`=7999;
UPDATE `creature_template` SET `ScriptName`='boss_fandral_staghelm' WHERE `entry`=3516;
UPDATE `creature_template` SET `ScriptName`='npc_lady_jaina_proudmoore' WHERE `entry`=4968;
UPDATE `creature_template` SET `ScriptName`='boss_voljin' WHERE `entry`=10540;
UPDATE `creature_template` SET `ScriptName`='boss_lorthemar_theron' WHERE `entry`=16802;
UPDATE `creature_template` SET `ScriptName`='generic_creature' WHERE `entry` in (16801, 34986, 1748);
REPLACE INTO spell_target_position VALUES
(20682, 1, -3992.637, -4717.926, 11.006, 0.7);
