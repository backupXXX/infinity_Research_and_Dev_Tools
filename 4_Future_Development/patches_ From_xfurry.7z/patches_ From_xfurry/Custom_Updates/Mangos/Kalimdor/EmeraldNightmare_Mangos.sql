/* NIGHTMARE */
UPDATE creature_template SET ScriptName="npc_keeper_remulos" WHERE entry=11832;
UPDATE creature_template SET ScriptName="boss_lethon" WHERE entry=14888;
UPDATE creature_template SET ScriptName="mob_spirit_shade" WHERE entry=15261;
