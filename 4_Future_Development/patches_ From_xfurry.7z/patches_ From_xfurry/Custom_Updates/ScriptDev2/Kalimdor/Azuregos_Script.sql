/* Azuregos */
DELETE FROM `script_texts` WHERE `entry` = '-1630010';
INSERT INTO script_texts (entry, emote, content_default, comment) VALUES
(-1630010, 0, "I said GOOD DAY!", "SAY_SpiritAzu_GoodBye");
